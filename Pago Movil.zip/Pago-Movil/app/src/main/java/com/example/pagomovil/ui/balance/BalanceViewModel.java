package com.example.pagomovil.ui.balance;

import androidx.lifecycle.ViewModel;

public class BalanceViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
